
var request = require('request');
var async = require('async');
var AWS = require('aws-sdk'); 
exports.handler = function(event, context){
    var requestUrls = [
        {
            "url":"http://elections.huffingtonpost.com/pollster/api/charts/2016-national-gop-primary.json",
            "keyname":"reps/EstimatesGOP"
        },{
            "url":"http://elections.huffingtonpost.com/pollster/api/charts/2016-national-democratic-primary.json",
            "keyname":"dems/EstimatesDEM"
        }]

    var partiesdone = 0;

    var uploadS3 = function(uploadobject,keyname){
        var s3 = new AWS.S3(); 
                s3.createBucket({Bucket: 'HuffPoPollsterDump'}, function() {

                    var params = {Bucket: 'HuffPoPollsterDump', Key: keyname, Body: JSON.stringify(uploadobject,null," ")}

                    s3.putObject(params, function(err, data) {

                        if (err){
                            console.log(err);
                            context.fail();
                        }else{
                            console.log("Successfully uploaded data to S3!");
                            partiesdone++;
                            if(partiesdone===2){
                               context.succeed(); 
                            }
                            
                        }
                   });
                });
    }

    var req = async.forEach(requestUrls, function(item,callback){
        
        request({
            url: item.url,
            json: true
        }, function(error, response, body){
            uploadS3(body,item.keyname);
        }, function(error){
            context.fail();
        })

    });

};



